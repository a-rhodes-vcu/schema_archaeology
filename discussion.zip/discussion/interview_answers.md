# P2P Context Engine

---

## Schema reasoning

> Can you interpret a legacy schema without documentation and produce accurate semantic labels? Do you ask good questions about ambiguous columns?

`schema_agent.py` crawls the database using `PRAGMA table_info` — no documentation required. It collects column names, types, sample values, distinct value counts, null percentages, and min/max ranges before sending any of it to Claude.

The heuristic FK detection catches implicit relationships by name pattern (`col_name ends in _id`) and flags the `sku` cross-reference between `po_line_items` and `receipt_lines` as a shared domain key with no constraint enforced — exactly the kind of undocumented join that breaks naive querying.

On ambiguous columns: `is_active` is a flag column that could mean anything. The crawl pulls all distinct values (`0`, `1`) and Claude labels it as a vendor deactivation flag — but the evaluation step then scores its own output and flags the gap:

> "No deactivation reason or offboarding workflow is documented."

That's the self-critique loop — rather than assuming the annotation is correct, we ask Claude to find its own blind spots and store the score in the JSON for downstream agents to weight confidence accordingly.

---

## Retrieval strategy

> Are you thinking about what the right "unit" to embed is? Do you understand precision vs. recall trade-offs for financial queries?

The unit of knowledge is a joined invoice summary, not a raw row. A raw `invoices` row has seven fields and no vendor name, no receipt status, no GL context. When a user asks *"which invoices failed 3-way match?"*, embedding that raw row produces near-zero recall because the embedding model has nothing to encode about match status.

The joined summary embeds sentences like:

```
3-way match complete: NO — missing receipt or GL
```

This sits close to match-failure queries in vector space even when the exact words differ.

**On precision vs recall:** pure semantic search over 5000 invoices has high recall but low precision for AP queries that have explicit structure — a question mentioning NET60 should only retrieve NET60 vendor invoices, not vaguely similar ones.

The SQL pre-filter pass handles precision: it narrows the candidate set to structurally correct invoices first, then semantic ranking handles recall within that set. Cosine distance above `1.2` triggers a low-confidence flag that instructs Claude to express uncertainty rather than hallucinate — because in financial queries a confident wrong answer is worse than an honest "I don't know."

---

## Financial domain awareness

> Do you understand what makes AP data sensitive? Do you know what a 3-way match is and why it matters?

AP data is sensitive for two reasons: it controls outbound cash flow, and it's one of the highest-fraud-risk areas in enterprise finance. Approval without receipt, inactive vendor payments, duplicate invoice numbers — these are all documented fraud vectors, not just data quality issues.

A **3-way match** is the core AP control: a payment should only be approved when three documents all agree on vendor, items, and amounts:

| Document | Purpose |
|---|---|
| Purchase Order | Authorises the spend |
| Goods Receipt | Confirms delivery |
| Invoice | Requests payment |

`AP-002` specifically catches invoices approved with no goods receipt — the match is incomplete before payment was authorised. The context packer also explicitly states 3-way match status in every embedded chunk rather than leaving the inference to the LLM, because retrieval precision for this query class depends on the conclusion being stated explicitly in the embedded text.

The GL checks (`GL-001`, `AP-001`) matter because they represent accounting records that don't exist — amounts showing on the P&L with no backing journal entries. These would fail any external audit and break the trial balance at month-end close.

---

## Anomaly instincts

> Do you go beyond the spec and find edge cases in the data we didn't tell you to look for?

The spec asked for four rules. Eight were implemented across five categories. The extra four:

| Rule | Severity | Description |
|---|---|---|
| `AP-002` | High | Invoices approved without a goods receipt — the more common AP fraud vector is approving payment before confirming delivery |
| `AP-003` | Medium | Pending invoices past their due date — a workflow stall that triggers late payment penalties and damages vendor relationships |
| `VND-001` | Medium | Open invoices from inactive vendors — either an offboarding failure or a fraud risk depending on how deactivation happened |
| `GL-001` | Critical | Imbalanced GL entries (debits ≠ credits) — a corrupted journal that will fail reconciliation, separate from and worse than missing GL entries |

`seed_db.py` intentionally seeds all anomalies at realistic rates (2–8%) so there is always something for the agent to find.

---

## AI leverage

> Are you using LLMs to reason about the schema and data, or just using them to write boilerplate SQL?

The LLM is used for reasoning, not boilerplate. Three places:

**`llm_annotate`** — Claude receives raw column names, types, sample values, and distinct value distributions and infers business meaning without any human documentation. It identifies that `account_code 2000` is the AP Control liability account, that `payment_terms NET60` means payment is due 60 days after invoice date, and that the `sku` join between `po_line_items` and `receipt_lines` is a domain key with no enforced constraint. A regex or a lookup table can't do this.

**`evaluate_schema_context`** — Claude reviews its own output and scores it 0–100, flagging accuracy risks and missing relationships. This is using the LLM as a quality gate rather than a content generator — the output of `llm_annotate` is only trusted downstream if the self-evaluation score is high enough.

**`query()` synthesis** — Claude is explicitly grounded: it answers using only the retrieved context and must say so if context is insufficient. The schema summary from `schema_context.json` is included in every synthesis prompt so Claude understands the business meaning of what it's reading. This is schema-aware RAG, not generic document QA.

---

## Shipping

> A runnable pipeline and at least one working question-answering demo by the end of the session.

Full pipeline runs in under 2 minutes from a clean install:

```bash
pip install anthropic chromadb
export ANTHROPIC_API_KEY=sk-ant-...

python seed_db.py          # ~2s   — creates p2p.db with anomalies
python schema_agent.py     # ~30s  — creates schema_context.json
python anomaly_agent.py    # ~1s   — creates anomaly_report.json
python rag_pipeline.py     # ~60s first run · answers 3 test questions automatically

streamlit run app.py       # chat UI · chunk inspector · confidence metrics per query
```

The ChromaDB index persists to disk so every run after the first loads in under a second.
